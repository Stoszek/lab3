using lab3_matrix;
using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;


namespace lab3
{
    public partial class Form1 : Form
    {
        private MatrixGenerator matrixGenerator;
        private Bitmap originalImage;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int matrixSize = int.Parse(textBox1.Text);
            int seed1 = int.Parse(textBox7.Text);
            int seed2 = int.Parse(textBox8.Text);

            matrixGenerator = new MatrixGenerator(seed1);

            int[,] matrixA = matrixGenerator.GenerateRandomMatrix(matrixSize, matrixSize);
            matrixGenerator = new MatrixGenerator(seed2);
            int[,] matrixB = matrixGenerator.GenerateRandomMatrix(matrixSize, matrixSize);

            //DisplayMatrix(matrixA, textBox3);
            //DisplayMatrix(matrixB, textBox4);

            int threadCount = int.Parse(textBox2.Text);
            int repetitions = 15;
            long totalMilliseconds = 0;
            long totalMilliseconds2 = 0;

            //Threads
            for (int i = 0; i < repetitions; i++)
            {
                Stopwatch stopwatch = Stopwatch.StartNew();
                int[,] resultMatrix = MultiplyMatricesParallelThreads(matrixA, matrixB, threadCount);
                stopwatch.Stop();

                totalMilliseconds += stopwatch.ElapsedMilliseconds;
            }

            long averageMilliseconds = totalMilliseconds / repetitions;

            //DisplayMatrix(resultMatrix, textBox6);

            textBox5.Text = $"{averageMilliseconds} ms";

            //Parallel
            for (int i = 0; i < repetitions; i++)
            {
                Stopwatch stopwatch2 = Stopwatch.StartNew();
                int[,] resultMatrix = MultiplyMatricesParallelLibrary(matrixA, matrixB, threadCount);
                stopwatch2.Stop();

                totalMilliseconds2 += stopwatch2.ElapsedMilliseconds;
            }

            long averageMilliseconds2 = totalMilliseconds2 / repetitions;

            textBox9.Text = $"{averageMilliseconds2} ms";
        }

        private int[,] MultiplyMatricesParallelLibrary(int[,] matrixA, int[,] matrixB, int threadCount)
        {
            int rows = matrixA.GetLength(0);
            int columns = matrixB.GetLength(1);
            int[,] resultMatrix = new int[rows, columns];

            int elementsPerThread = rows * columns / threadCount;

            Parallel.For(0, threadCount, (threadIndex) =>
            {
                int start = threadIndex * elementsPerThread;
                int end = (threadIndex == threadCount - 1) ? rows * columns : (threadIndex + 1) * elementsPerThread;

                for (int index = start; index < end; index++)
                {
                    int row = index / columns;
                    int col = index % columns;

                    for (int k = 0; k < matrixA.GetLength(1); k++)
                    {
                        resultMatrix[row, col] += matrixA[row, k] * matrixB[k, col];
                    }
                }
            });

            return resultMatrix;
        }




        private void DisplayMatrix(int[,] matrix, TextBox textBox)
        {
            int rows = matrix.GetLength(0);
            int columns = matrix.GetLength(1);
            textBox.Clear();
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    textBox.AppendText(matrix[i, j] + "\t");
                }
                textBox.AppendText(Environment.NewLine);
            }
            textBox.AppendText(Environment.NewLine);
        }

        private int[,] MultiplyMatricesParallelThreads(int[,] matrixA, int[,] matrixB, int threadCount)
        {
            int rows = matrixA.GetLength(0);
            int columns = matrixB.GetLength(1);
            int[,] resultMatrix = new int[rows, columns];
            int elementsPerThread = rows * columns / threadCount;

            Thread[] threads = new Thread[threadCount];

            for (int i = 0; i < threadCount; i++)
            {
                int start = i * elementsPerThread;
                int end = (i == threadCount - 1) ? rows * columns : (i + 1) * elementsPerThread;

                threads[i] = new Thread(() =>
                {
                    for (int index = start; index < end; index++)
                    {
                        int row = index / columns;
                        int col = index % columns;

                        for (int k = 0; k < matrixA.GetLength(1); k++)
                        {
                            resultMatrix[row, col] += matrixA[row, k] * matrixB[k, col];
                        }
                    }
                });
                threads[i].Start();
            }

            foreach (var thread in threads)
            {
                thread.Join();
            }

            return resultMatrix;
        }

        private void ApplyGrayscale(Bitmap inputImage, Bitmap processedImage)
        {
            for (int y = 0; y < inputImage.Height; y++)
            {
                for (int x = 0; x < inputImage.Width; x++)
                {
                    Color pixelColor = inputImage.GetPixel(x, y);
                    int grayValue = (int)(0.299 * pixelColor.R + 0.587 * pixelColor.G + 0.114 * pixelColor.B);
                    Color newColor = Color.FromArgb(pixelColor.A, grayValue, grayValue, grayValue);
                    processedImage.SetPixel(x, y, newColor);
                }
            }
        }

        private void ApplyMirror(Bitmap inputImage, Bitmap processedImage)
        {
            for (int y = 0; y < inputImage.Height; y++)
            {
                for (int x = 0; x < inputImage.Width; x++)
                {
                    Color pixelColor = inputImage.GetPixel(inputImage.Width - x - 1, y);
                    processedImage.SetPixel(x, y, pixelColor);
                }
            }
        }

        private void ApplyThreshold(Bitmap inputImage, Bitmap processedImage, int threshold)
        {
            for (int y = 0; y < inputImage.Height; y++)
            {
                for (int x = 0; x < inputImage.Width; x++)
                {
                    Color pixelColor = inputImage.GetPixel(x, y);
                    int grayValue = (int)(0.299 * pixelColor.R + 0.587 * pixelColor.G + 0.114 * pixelColor.B);
                    Color newColor = grayValue > threshold ? Color.White : Color.Black;
                    processedImage.SetPixel(x, y, newColor);
                }
            }
        }

        private void ApplyNegative(Bitmap inputImage, Bitmap processedImage)
        {
            for (int y = 0; y < inputImage.Height; y++)
            {
                for (int x = 0; x < inputImage.Width; x++)
                {
                    Color pixelColor = inputImage.GetPixel(x, y);
                    Color newColor = Color.FromArgb(pixelColor.A, 255 - pixelColor.R, 255 - pixelColor.G, 255 - pixelColor.B);
                    processedImage.SetPixel(x, y, newColor);
                }
            }
        }

        private void ApplyFiltersParallel()
        {
 
                    if (originalImage == null)
                    {
                        MessageBox.Show("Wczytaj obraz przed zastosowaniem filtr�w!", "B��d", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    Bitmap processedImageGray = new Bitmap(originalImage.Width, originalImage.Height);
                    Bitmap processedImageMirror = new Bitmap(originalImage.Width, originalImage.Height);
                    Bitmap processedImageThreshold = new Bitmap(originalImage.Width, originalImage.Height);
                    Bitmap processedImageNegative = new Bitmap(originalImage.Width, originalImage.Height);

                    int threshold = 128;

                    /* ThreadPool.QueueUserWorkItem((state) => ApplyGrayscale(originalImage, processedImageGray));
                    ThreadPool.QueueUserWorkItem((state) => ApplyMirror(originalImage, processedImageMirror));
                    ThreadPool.QueueUserWorkItem((state) => ApplyThreshold(originalImage, processedImageThreshold, threshold));
                    ThreadPool.QueueUserWorkItem((state) => ApplyNegative(originalImage, processedImageNegative));

                    while (ThreadPool.PendingWorkItemCount > 0) { } */

                    ApplyGrayscale(originalImage, processedImageGray);
                    ApplyMirror(originalImage, processedImageMirror);
                    ApplyThreshold(originalImage, processedImageThreshold, threshold);
                    ApplyNegative(originalImage, processedImageNegative);

                    pictureBox2.Image = processedImageGray;
                    pictureBox3.Image = processedImageMirror;
                    pictureBox4.Image = processedImageThreshold;
                    pictureBox5.Image = processedImageNegative;
        }


        private void button3_Click(object sender, EventArgs e)
        {
            ApplyFiltersParallel();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.jpg; *.jpeg; *.png; *.bmp)|*.jpg; *.jpeg; *.png; *.bmp|All files (*.*)|*.*";
            openFileDialog.FilterIndex = 1;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                originalImage = new Bitmap(openFileDialog.FileName);
                pictureBox1.Image = originalImage;
            }
        }
    }

}
