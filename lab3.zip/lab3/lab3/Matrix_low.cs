﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3_matrix
{
    using System;

    public class MatrixGenerator
    {
        private Random random;

        public MatrixGenerator(int seed)
        {
            random = new Random(seed);
        }

        public int[,] GenerateRandomMatrix(int rows, int columns)
        {
            int[,] matrix = new int[rows, columns];
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    matrix[i, j] = random.Next(100); // Zakładamy wartości od 0 do 99
                }
            }
            return matrix;
        }

        public void DisplayMatrix(int[,] matrix, string title)
        {
            Console.WriteLine(title);
            int rows = matrix.GetLength(0);
            int columns = matrix.GetLength(1);
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    Console.Write(matrix[i, j] + "\t");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }
    }


}
